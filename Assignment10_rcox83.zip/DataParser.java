import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class DataParser {

    public static SchoolDistrictData[] parseData(String filePath, int maxDistricts) throws IOException {
        SchoolDistrictData[] districts = new SchoolDistrictData[maxDistricts];
        int districtCount = 0;

        try (BufferedReader reader = new BufferedReader(new FileReader(filePath))) {
            String line;
            while ((line = reader.readLine()) != null && districtCount < maxDistricts) {
                districts[districtCount++] = parseLine(line);
            }
        }

        return districts;
    }

    private static SchoolDistrictData parseLine(String line) {
        // Parsing logic as before...
    }
}
