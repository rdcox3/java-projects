import java.util.Arrays;

public class ReportGenerator {

    public static void generateReport(SchoolDistrictData[] districts, int districtCount) {
        // Sort the array based on state code as before...
        // The rest of the report generation logic as before...
    }

    private static void printStateData(String stateCode, int totalPopulation, int totalChildPopulation, int totalChildPovertyPopulation) {
        // Printing logic as before...
    }
}
