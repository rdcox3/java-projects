public class Main {
    private static final int MAX_DISTRICTS = 1000;

    public static void main(String[] args) {
        String filePath = "SmallAreaIncomePovertyEstData .txt"; // Data File
        
        try {
            SchoolDistrictData[] districts = DataParser.parseData(filePath, MAX_DISTRICTS);
            ReportGenerator.generateReport(districts, districts.length);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}// end class main
