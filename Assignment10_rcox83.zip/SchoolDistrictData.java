public class SchoolDistrictData {
    private String stateCode;
    private String districtName;
    private int totalPopulation;
    private int childPopulation;
    private int childPovertyPopulation;

    // Constructor
    public SchoolDistrictData(String stateCode, String districtName, int totalPopulation, int childPopulation, int childPovertyPopulation) {
        this.stateCode = stateCode;
        this.districtName = districtName;
        this.totalPopulation = totalPopulation;
        this.childPopulation = childPopulation;
        this.childPovertyPopulation = childPovertyPopulation;
    }

    // Getters
    public String getStateCode() {
        return stateCode;
    }

    public String getDistrictName() {
        return districtName;
    }

    public int getTotalPopulation() {
        return totalPopulation;
    }

    public int getChildPopulation() {
        return childPopulation;
    }

    public int getChildPovertyPopulation() {
        return childPovertyPopulation;
    }

    // Setters
    public void setStateCode(String stateCode) {
        this.stateCode = stateCode;
    }

    public void setDistrictName(String districtName) {
        this.districtName = districtName;
    }

    public void setTotalPopulation(int totalPopulation) {
        this.totalPopulation = totalPopulation;
    }

    public void setChildPopulation(int childPopulation) {
        this.childPopulation = childPopulation;
    }

    public void setChildPovertyPopulation(int childPovertyPopulation) {
        this.childPovertyPopulation = childPovertyPopulation;
    }
}//end class SchoolDistrictData
