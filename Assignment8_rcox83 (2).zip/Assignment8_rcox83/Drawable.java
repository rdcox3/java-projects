/*
Ron Cox
Java 605.201.83
Assignment 8
*/

public interface Drawable {
    void drawObject();
}//end class Drawable