/*
Ron Cox
Java 605.201.83
Assignment 8
*/

public interface Resizable {
    void resizeObject();
}//end class Resizable
