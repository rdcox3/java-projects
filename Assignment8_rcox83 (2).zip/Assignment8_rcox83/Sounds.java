/*
Ron Cox
Java 605.201.83
Assignment 8
*/

public interface Sounds {
    void playSound();
}//end class Sounds